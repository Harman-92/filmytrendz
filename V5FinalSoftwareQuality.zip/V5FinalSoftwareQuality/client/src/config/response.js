const response = {
    SERVER_UNAVAILABLE : 'Server unavailable, Please try again later...',
    REGISTRATION_ERROR : 'Registration Failed!',
    LOGIN_ERROR : 'Login Failed',
    SERVER_ERROR : 'Internal Server Error',
    INVALID_TOKEN : 'Invalid Token'
}

export default response
